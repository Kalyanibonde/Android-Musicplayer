package com.example.mysong;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;
import android.widget.SeekBar;

public class MainActivity extends AppCompatActivity {

    ImageView play,stop,pause,back,next;
    MediaPlayer player;
    SeekBar sb;
    Handler handler = new Handler();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        player = MediaPlayer.create(this,R.raw.song);
        sb = (SeekBar) findViewById(R.id.sb);
        sb.setMax(player.getDuration());
        play = findViewById(R.id.img2);
        stop = findViewById(R.id.img4);
        pause = findViewById(R.id.img3);
        back = findViewById(R.id.img1);
        next = findViewById(R.id.img5) ;
        play.setEnabled(true);
        pause.setEnabled(false);
        stop.setEnabled(false);

        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                if(b)
                {
                    player.seekTo(i);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        updateSeekBar();

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                player.seekTo(player.getCurrentPosition()-(player.getDuration()/10));
            }
        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                player.seekTo(player.getCurrentPosition()+(player.getDuration()/10));
            }
        });

        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                player.start();
                play.setEnabled(false);
                stop.setEnabled(true);
                pause.setEnabled(true);
            }
        });

        pause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                player.pause();
                play.setEnabled(true);
                pause.setEnabled(false);
            }
        });

        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                player.stop();
                play.setEnabled(true);
                stop.setEnabled(false);
                pause.setEnabled(false);
                player = MediaPlayer.create(MainActivity.this,R.raw.song);
            }
        });


    }

    public void updateSeekBar()
    {
        sb.setProgress(player.getCurrentPosition());
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                updateSeekBar();
            }
        },1000);
    }


}